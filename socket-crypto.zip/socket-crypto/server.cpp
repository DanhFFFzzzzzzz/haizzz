/* A simple server in the internet domain using TCP
   The port number is passed as an argument */
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <iostream>
#include <string>
#include <fstream>
#include "des.cpp"

#define BUFFER_SIZE 256

/* FILE TRANSFERRING SYSTEM */

void error(const char *msg) {
    perror(msg);
    exit(1);
}

int innit_server_socket(int portno) {
    int sockfd;
    struct sockaddr_in serv_addr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) error("ERROR: Can't create socket");

    bzero((char *)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    int bind_result =
        bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));

    if (bind_result < 0) error("ERROR: Can't bind socket");

    listen(sockfd, 5);

    std::cout << "Waiting for client on port " << portno << "..." << std::endl;
    return sockfd;
}

int accept_client(int sockfd) {
    int newsockfd, clilen;
    struct sockaddr_in cli_addr;

    clilen = sizeof(cli_addr);

    newsockfd =
        accept(sockfd, (struct sockaddr *)&cli_addr, (socklen_t *)&clilen);
    if (newsockfd < 0) error("ERROR on accept");

    return newsockfd;
}

void send_file_extension(int sockfd, char *filename) {
    char *extension = strrchr(filename, '.');
    if (extension == NULL) {
        error("ERROR: File has no extension");
    }

    if (send(sockfd, extension, strlen(extension), 0) < 0) {
        error("ERROR: Can't send file extension");
    }
}

void send_file(int sockfd, std::string filename, std::string key) {
    int n;

    FileEncryptor fe(key);
    fe.encrypt_file(filename, "encrypted-sv");

    std::ifstream file("encrypted-sv", std::ios::binary);

    if (!file.is_open()) {
        error("ERROR: Can't open file");
    }

    std::vector<char> buffer(BUFFER_SIZE);

    while (!file.eof()) {
        file.read(buffer.data(), BUFFER_SIZE);
        std::cout << "Sending " << file.gcount() << " bytes" << std::endl;
        n = send(sockfd, buffer.data(), file.gcount(), 0);
        if (n < 0) {
            error("ERROR: Can't write to socket");
        }
    }
}

void wait_for_ok(int sockfd) {
    char buffer[BUFFER_SIZE];
    int n;

    bzero(buffer, BUFFER_SIZE);
    n = read(sockfd, buffer, BUFFER_SIZE);
    if (n < 0) {
        error("ERROR: Can't read from socket");
    }
    if (strcmp(buffer, "OK") != 0) {
        error("ERROR: Client didn't send OK");
    }
}

int main(int argc, char *argv[]) {
    int sockfd, newsockfd, portno, n;
    char buffer[BUFFER_SIZE];

    if (argc < 2) {
        fprintf(stderr, "usage %s port\n", argv[0]);
        exit(1);
    }

    std::string key = "1110";

    sockfd = innit_server_socket(atoi(argv[1]));
    newsockfd = accept_client(sockfd);

    printf("Connected\n");
    printf("Enter the file to send: ");
    bzero(buffer, BUFFER_SIZE);
    fgets(buffer, BUFFER_SIZE, stdin);
    buffer[strlen(buffer) - 1] = '\0';

    send_file_extension(newsockfd, buffer);
    wait_for_ok(newsockfd);
    send_file(newsockfd, buffer, key);

    return 0;
}