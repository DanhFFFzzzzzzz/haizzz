#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/time.h>
#include <linux/jiffies.h>

#define DRIVER_AUTHOR "linh"
#define DRIVER_DESC   "Wall time and system uptime"
#define VERSION "3.0"
#define MEM_SIZE 1024

struct vchar_drv {
	dev_t dev_num;
	struct class *dev_class;
	struct device *dev;
} vchar_drv;

static struct cdev *example_cdev;
unsigned long js;

static int lab52_open(struct inode *inode, struct file *filp);
static int lab52_release(struct inode *inode, struct file *filp);
static ssize_t lab52_read(struct file *filp, char __user *user_buf, size_t len, loff_t *off);
static ssize_t lab52_write(struct file *filp, const char __user *user_buf, size_t len, loff_t *off);

static struct file_operations fops =
{
	.owner          = THIS_MODULE,
	.read           = lab52_read,
	.write          = lab52_write,
	.open           = lab52_open,
	.release        = lab52_release,
};

static int lab52_open(struct inode *inode, struct file *filp)
{
	printk("Mở file\n");
	return 0;
}

static int lab52_release(struct inode *inode, struct file *filp)
{
	printk("Đóng file\n");
	return 0;
}

static ssize_t lab52_read(struct file *filp, char __user *user_buf, size_t len, loff_t *off)
{
	struct timespec64 ts;
	unsigned long jf;
	long result[3] = {0};

	ktime_get_real_ts64(&ts);
	result[0] = ts.tv_sec;
	result[1] = ts.tv_nsec;

	jf = jiffies;
	result[2] = jiffies_to_msecs(jf - js);

	copy_to_user(user_buf, result, sizeof(result));
	return sizeof(result);
}

static ssize_t lab52_write(struct file *filp, const char __user *user_buf, size_t len, loff_t *off)
{
	return len;
}

static int __init char_driver_init(void)
{
	int ret = 0;

	ret = alloc_chrdev_region(&vchar_drv.dev_num, 0, 1, "lab5.2-linh");
	if (ret < 0) {
		printk("Không thể cấp phát driver ký tự\n");
		goto failed_register_devnum;
	}
	printk("Đã cài đặt driver ký tự thành công. major(%d), minor(%d)\n", MAJOR(vchar_drv.dev_num), MINOR(vchar_drv.dev_num));

	vchar_drv.dev_class = class_create("lab5.2-class");
	if (IS_ERR(vchar_drv.dev_class)) {
		printk("Không thể tạo class\n");
		goto failed_create_class;
	}

	vchar_drv.dev = device_create(vchar_drv.dev_class, NULL, vchar_drv.dev_num, NULL, "lab5.2-linh");
	if (IS_ERR(vchar_drv.dev)) {
		printk("Không thể tạo file thiết bị\n");
		goto failed_create_device;
	}

	example_cdev = cdev_alloc();
	cdev_init(example_cdev, &fops);
	ret = cdev_add(example_cdev, vchar_drv.dev_num, 1);
	if (ret < 0) {
		printk("Thêm thiết bị ký tự không thành công\n");
		goto failed_create_device;
	}

	js = jiffies;

	return 0;

failed_create_device:
	class_destroy(vchar_drv.dev_class);
failed_create_class:
	unregister_chrdev_region(vchar_drv.dev_num, 1);
failed_register_devnum:
	return ret;
}

static void __exit char_driver_exit(void)
{
	cdev_del(example_cdev);
	device_destroy(vchar_drv.dev_class, vchar_drv.dev_num);
	class_destroy(vchar_drv.dev_class);
	unregister_chrdev_region(vchar_drv.dev_num, 1);
	printk("Gỡ bỏ driver ký tự thành công.\n");
}

module_init(char_driver_init);
module_exit(char_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_VERSION(VERSION);

