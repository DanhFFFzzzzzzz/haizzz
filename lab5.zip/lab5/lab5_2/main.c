#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h> // Thêm vào đây để sử dụng errno

#define DEVICE_NODE "/dev/lab5.2-linh"

int main() {
    int fd;
    int option;
    long data[3];

    fd = open(DEVICE_NODE, O_RDWR);
    if (fd < 0) {
        perror("Không thể mở thiết bị...");
        return errno; // Sử dụng errno ở đây
    }

    while (1) {
        printf("\nMenu chức năng\n");
        printf("1. Lấy thời gian tuyệt đối, chính xác đến micro giây\n");
        printf("2. Lấy thời gian tuyệt đối, chính xác đến nano giây\n");
        printf("3. Lấy thời gian tương đối\n");
        printf("4. Kết thúc ctr\n");
        printf("Chọn: ");
        scanf("%d", &option);

        switch (option) {
            case 1:
                read(fd, data, sizeof(data));
                printf("Thời gian tuyệt đối (micro giây): %ld giây, %ld micro giây\n", data[0], data[1] / 1000);
                break;
            case 2:
                read(fd, data, sizeof(data));
                printf("Thời gian tuyệt đối (nano giây): %ld giây, %ld nano giây\n", data[0], data[1]);
                break;
            case 3:
                read(fd, data, sizeof(data));
                printf("Thời gian tương đối: %ld milliseconds\n", data[2]);
                break;
            case 4:
                close(fd);
                return 0;
            default:
                printf("Lựa chọn không hợp lệ. Vui lòng chọn lại.\n");
                break;
        }
    }

    return 0;
}

