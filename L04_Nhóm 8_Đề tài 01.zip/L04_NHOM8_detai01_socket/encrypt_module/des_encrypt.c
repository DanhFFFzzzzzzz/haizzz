#include <linux/module.h>
#include <linux/crypto.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/ctype.h>
#include <crypto/internal/cipher.h>
#include <crypto/algapi.h>
#include <crypto/internal/skcipher.h>

#define MEM_SIZE 1024

uint8_t *kernel_buffer; // Con trỏ đến vùng nhớ kernel được cấp phát để lưu trữ dữ liệu
dev_t dev_num; // số thiết bị gán cho driver
struct class *device_class; // class của driver
struct cdev *char_device; // cấu trúc đại diện cho driver ký tự
struct crypto_cipher *tfm; // con trỏ đến cấu trúc 'crypto_cipher' đại diện cho thuật toán mã hóa DES
char key[8] = "01234567"; // khóa mã hóa DES
char type[100]; // chuỗi lưu trữ lệnh mã hóa hoặc giải mã
char data[MEM_SIZE]; // chuỗi lưu dữ liệu cần mã hóa hoặc giải mã
size_t data_len = 0; // độ dài dữ liệu

// chuyển đổi hex sang string
static int hextostring(char *in, int len, char *out)
{
    int i;

    for (i = 0; i < len; i++)
    {
        sprintf(out, "%s%02hhx", out, in[i]);
    }
    return 0;
}

// chuyển đổi string sang hex
static int stringtohex(char *in, int len, char *out)
{
    int i;
    int converter[105];
    converter['0'] = 0;
    converter['1'] = 1;
    converter['2'] = 2;
    converter['3'] = 3;
    converter['4'] = 4;
    converter['5'] = 5;
    converter['6'] = 6;
    converter['7'] = 7;
    converter['8'] = 8;
    converter['9'] = 9;
    converter['a'] = 10;
    converter['b'] = 11;
    converter['c'] = 12;
    converter['d'] = 13;
    converter['e'] = 14;
    converter['f'] = 15;

    for (i = 0; i < len; i = i + 2)
    {
        char byte = converter[(int)in[i]] << 4 | converter[(int)in[i + 1]];
        out[i / 2] = byte;
    }

    return 0;
}

// hàm được gọi khi mở thiết bị
static int open_fun(struct inode *inode, struct file *file)
{
    return 0;
}

//hàm được gọi khi đóng thiết bị
static int release_fun(struct inode *inode, struct file *file)
{
    return 0;
}

// hàm đọc dữ liệu từ thiết bị
static ssize_t read_fun(struct file *file, char *user_buf, size_t len, loff_t *off)
{
    char cipher[1000]; // hàm lưu trữ dữ liệu sau khi giả hoặc mã hóa
    char hex_cipher[1000]; // hàm lưu dữ liệu mã hóa, giải mã dưới dạng hex
    int i, j;

    printk("data_len: %ld\n", data_len); 

    memset(cipher, 0, sizeof(cipher)); // xóa bộ nhớ của cipher để lưu trữ dữ liệu mới
    memset(hex_cipher, 0, sizeof(hex_cipher)); // xóa bộ nhớ để lưu trữ dữ liệu mới

    for (i = 0; i < data_len / 8; i++) // lặp qua từng khối dữ liệu có độ dài 8byte
    {
        char one_data[9], one_cipher[9]; 

        memset(one_data, 0, sizeof(one_data));
        memset(one_cipher, 0, sizeof(one_cipher));

        for (j = 0; j < 8; j++) // copy 1 khối dữ liệu
            one_data[j] = data[i * 8 + j]; // sao chép 1 khỗi dữ liệu từ mảng data và one_data

        printk("one data: %s\n", one_data);

        if (strcmp(type, "encrypt") == 0) // mã hóa dữ liệu 
            crypto_cipher_encrypt_one(tfm, one_cipher, one_data);
        if (strcmp(type, "decrypt") == 0) // giải mã dữ liệu
            crypto_cipher_decrypt_one(tfm, one_cipher, one_data);
        for (j = 0; j < 8; j++) // copy vào block cuối cùng
            cipher[i * 8 + j] = one_cipher[j]; // sao chép dữ liệu mã hóa từ one_cipher vào cipher

        printk("one cipher: %s\n", one_cipher);
    }

    hextostring(cipher, data_len, hex_cipher);
    printk("hex cipher: %s\n", hex_cipher); //
    copy_to_user(user_buf, hex_cipher, data_len * 2);

    return 0;
}

// hàm ghi dữ liệu vào thiết bị
static ssize_t write_fun(struct file *file, const char *user_buff, size_t len, loff_t *off)
{
    char buffer[1000], hex_data[1000];
    int i, j;

    memset(buffer, 0, sizeof(buffer));
    memset(data, 0, sizeof(data));
    memset(type, 0, sizeof(type));
    memset(hex_data, 0, sizeof(hex_data));

    copy_from_user(buffer, user_buff, len);

    i = 0;
    j = 0;
    while (buffer[i] != '\n' && j < len)  // tách lệnh: mã_hóa hoặc giải_mã
    {
        type[i] = buffer[j];
        i++;
        j++;
    }

    i = 0;
    j++;
    while (j < len) // đọc dữ liệu
    {
        hex_data[i] = buffer[j];
        i++;
        j++;
    }

    printk("type: %s\n", type);
    printk("hex_data: %s\n", hex_data);

    memset(buffer, 0, sizeof(buffer));
    stringtohex(hex_data, strlen(hex_data), data);
    printk("data: %s\n", data);

    if (strlen(hex_data) % 16 == 0)  // add padding cho data
        data_len = ((uint16_t)(strlen(hex_data) / 16)) * 8;
    else
        data_len = ((uint16_t)((strlen(hex_data) / 16) + 1)) * 8;
    return 0;
}

// hàm sử lý các operations được gán cho driver
static struct file_operations fops = {
    .owner = THIS_MODULE,
    .read = read_fun,
    .write = write_fun,
    .open = open_fun,
    .release = release_fun};

static int md_init(void)
{
    printk("Cài đặt module\n");

    tfm = crypto_alloc_cipher("des", 0, 0); // khởi tạo bộ mã hóa DES
    crypto_cipher_setkey(tfm, key, 8); // thiết lập khóa mã hóa

    alloc_chrdev_region(&dev_num, 0, 1, "tenthietbi"); // tạo driver
    device_class = class_create(THIS_MODULE, "class"); // tạo class cho driver
    device_create(device_class, NULL, dev_num, NULL, "des_encrypt"); // tạo thiết bị

    kernel_buffer = kmalloc(MEM_SIZE, GFP_KERNEL); // cấp phát bộ nhớ cho kernel

    char_device = cdev_alloc();  // cấp phát char driver
    cdev_init(char_device, &fops);  // khởi tạo 
    cdev_add(char_device, dev_num, 1); // thêm driver vào hệ thống

    return 0;
}

static void md_exit(void)
{
    crypto_free_cipher(tfm); // giải phóng bộ nhớ
    cdev_del(char_device);
    kfree(kernel_buffer);
    device_destroy(device_class, dev_num);
    class_destroy(device_class);
    unregister_chrdev_region(dev_num, 1);
    printk("Thoát module\n");
}

module_init(md_init);
module_exit(md_exit);
MODULE_IMPORT_NS(CRYPTO_INTERNAL);
MODULE_LICENSE("GPL");

/*
Luồng thực thi của module sẽ được điều khiển bởi hệ điều hành Linux kernel.
Khi module được tải vào kernel, hàm md_init sẽ được gọi để khởi tạo module và đăng ký các tài nguyên cần thiết (bộ mã hóa, driver, bộ nhớ, v.v.).
Module sẽ trở thành một phần của kernel và có thể thực hiện các hoạt động mã hóa và giải mã dữ liệu theo yêu cầu của người dùng thông qua các file operations.
Khi module được gỡ bỏ khỏi kernel, hàm md_exit sẽ được gọi để giải phóng tài nguyên và hủy đăng ký của module.

*/