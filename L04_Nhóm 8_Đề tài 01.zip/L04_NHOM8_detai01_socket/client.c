#include <fcntl.h>
#include <stdint.h>    
#include <pthread.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define PORT_NUM 4000 // cổng sử dụng để kết nối tới máy chủ
#define SERVER_ADDR "127.0.0.1" // địa chỉ IP máy chủ

int server_fd; // File descriptor của socket kết nối tới máy chủ
pthread_t receive_thread, sent_thread; // Luồng để nhận và gửi tin nhắn

int hextostring(char *in, int len, char *out)
{
    int i;

    memset(out, 0, sizeof(out));
    for (i = 0; i < len; i++)
    {
        sprintf(out, "%s%02hhx", out, in[i]); // hàm sprintf để định dạng giá trị hẽ và lưu vào chuỗi kết quả out
    }
    return 0;
}

int stringtohex(char *in, int len, char *out)
{
    int i;
    int converter[105];
    converter['0'] = 0;
    converter['1'] = 1;
    converter['2'] = 2;
    converter['3'] = 3;
    converter['4'] = 4;
    converter['5'] = 5;
    converter['6'] = 6;
    converter['7'] = 7;
    converter['8'] = 8;
    converter['9'] = 9;
    converter['a'] = 10;
    converter['b'] = 11;
    converter['c'] = 12;
    converter['d'] = 13;
    converter['e'] = 14;
    converter['f'] = 15;

    memset(out, 0, sizeof(out));

    for (i = 0; i < len; i = i + 2)
    {
        char byte = converter[in[i]] << 4 | converter[in[i + 1]];
        out[i / 2] = byte;
    }
}

/*
Hàm recive_message là một luồng độc lập chạy song song với luồng chính. 
trong vòng lặp vô hạn, luồng này sẽ gọi hàm read để nhận kích thước giá trị tin nhắn 
và sau đó đọc tin nhắn từ socket vào mảng buffer, tin nhắn có định dạng là "name:hex_message"
trong đó năm là trên người gủi và hex_message là nội dung tin nhắn dưới dạng hex. 
sau đó luồng gửi tin nhắn cần giải mã và in ra màn hình
*/
static void *receive_message(void *fun_arg)
{
    int *server_fd = (int *)fun_arg; // con trỏ fun_arg chứa địa chỉ biến'server_fd', được ép kiểu thành int
    //server_fd: con trỏ được gắn bằng giá trị của fun_arg, để truy cập vào file descriptor của socket kết nối vơi server
    uint16_t receive_byte; // lưu kích thước tin nhắn nhận được
    char buffer[1200], name[100], hex_message[1000], message[1200];
    // buffer : lưu tin nhắn nhận được từ server
    // name: lưu tên người gửi tin nhắn
    // hex_message: lưu nôi dung tin nhắn dưới dnagj hex
    // message: lưu tin nhắn dưới dạng string
    int des_fd = open("/dev/des_encrypt", O_RDWR); // /mở file với quyền đọc và ghi, kết quả trả về des_fd, được sử dụng để gửi tin nhắn tới module /dev/des_encrypt để giải mã
    while (1)
    {
        memset(buffer, 0, sizeof(buffer));
        if (read(*server_fd, &receive_byte, sizeof(receive_byte)) == 0)
        {
            printf("disconnect from server\n");
            exit(0);
        }
        if (read(*server_fd, buffer, receive_byte) == 0)
        {
            printf("disconnect from server\n");
            exit(0);
        }
        sscanf(buffer, "%[^:]: %[0-9abcdef]", name, hex_message);

        memset(buffer, 0, sizeof(buffer));
        sprintf(buffer, "decrypt\n%s", hex_message);
        write(des_fd, buffer, strlen(buffer));

        memset(hex_message, 0, sizeof(hex_message));
        read(des_fd, hex_message, sizeof(hex_message));  // giai ma

        stringtohex(hex_message, sizeof(hex_message), message);
        printf("%s: %s\n", name, message);
        
    }
    close(des_fd);
}

/*
Hàm send_message cũng là một luồng độc lập chạy song song với luồng chính.
 Trong vòng lặp vô hạn, luồng này sẽ đọc tin nhắn từ người dùng bằng hàm fgets và loại bỏ ký tự newline.
Sau đó, tin nhắn được chuyển đổi từ dạng chuỗi sang dạng hex bằng hàm hextostring. 
Tiếp theo, tin nhắn được gửi tới module /dev/des_encrypt để mã hóa và sau đó gửi tin nhắn đã mã hóa tới server.
*/
static void *send_message(void *fun_arg)
{
    int *server_fd = (int *)fun_arg; //Con trỏ void chứa địa chỉ của biến server_fd, được ép kiểu thành int*.
    //server_fd: Con trỏ được gán bằng giá trị của fun_arg, để truy cập vào file descriptor của socket kết nối với server.
    uint16_t sent_byte; // kích thước của tin nhắn gửi đi
    char message[1000], hex_message[1000], encrypt_message[1200];
    //message: Mảng ký tự dùng để lưu trữ tin nhắn được nhập từ người dùng.
    //hex_message: Mảng ký tự dùng để lưu trữ nội dung tin nhắn dưới dạng hex.
    //encrypt_message: Mảng ký tự dùng để lưu trữ tin nhắn sau khi được mã hóa và chuẩn bị để gửi đi

    int des_fd = open("/dev/des_encrypt", O_RDWR);
    //Sử dụng hàm open để mở file /dev/des_encrypt với quyền đọc và ghi (O_RDWR). 
    //Kết quả trả về là file descriptor des_fd, được sử dụng để gửi tin nhắn tới module /dev/des_encrypt để mã hóa.
    if (des_fd == -1) {
        printf("khong mo dc file driver\n");
        exit(0);
    }

    while (1)
    {
        memset(message, 0, sizeof(message));
        // Đặt tất cả các phần tử của mảng message về 0, để chuẩn bị cho việc nhận tin nhắn từ người dùng.

        fgets(message, sizeof(message), stdin);
        //Nhận tin nhắn từ người dùng thông qua hàm fgets và lưu vào mảng message
        message[strlen(message) - 1] = 0; //Dòng cuối cùng của tin nhắn (ký tự xuống dòng) được loại bỏ bằng cách đặt ký tự kết thúc chuỗi ('\0') tại vị trí đó.

        if (strlen(message) != 0) //Kiểm tra xem tin nhắn có chiều dài khác 0 hay không. Nếu tin nhắn không rỗng, thực hiện các bước tiếp theo.
        {
            hextostring(message, strlen(message), hex_message); 
            sprintf(encrypt_message, "encrypt\n%s", hex_message);
            write(des_fd, encrypt_message, strlen(encrypt_message)); //Gửi tin nhắn encrypt_message tới module /dev/des_encrypt để mã hóa bằng cách sử dụng hàm write.

            memset(encrypt_message, 0, sizeof(encrypt_message)); //Đặt tất cả các phần tử của mảng encrypt_message về 0, để chuẩn bị cho việc nhận tin nhắn đã được mã hóa từ module /dev/des_encrypt.
            read(des_fd, encrypt_message, sizeof(encrypt_message)); // Đọc tin nhắn đã được mã hóa từ module /dev/des_encrypt và lưu vào mảng encrypt_message.

            sent_byte = strlen(encrypt_message); //Gán kích thước của tin nhắn đã mã hóa (encrypt_message) cho biến sent_byte.
            write(*server_fd, &sent_byte, sizeof(sent_byte)); // gui tin nhan den server
            write(*server_fd, encrypt_message, sent_byte);//Gửi tin nhắn đã mã hóa tới server bằng cách sử dụng hàm write.
        }
        

    }
    close(des_fd);//Đóng file descriptor des_fd sau khi hoàn thành việc gửi tin nhắn.
}

/*
Trong cả hai hàm receive_message và send_message, một vòng lặp vô hạn được sử dụng để liên tục nhận và gửi tin nhắn,
 đảm bảo rằng chương trình không kết thúc sau khi nhận/gửi một tin nhắn duy nhất.
*/

//Hàm setname cho phép người dùng nhập tên và gửi tên đến server để xác định danh tính của người dùng.
int setname(int server_fd)
{
    char name[100];
    uint16_t send_byte;

    printf("chat name: ");
    fgets(name, sizeof(name), stdin);
    name[strlen(name) - 1] = 0;
    send_byte = strlen(name);
    write(server_fd, &send_byte, sizeof(send_byte));
    write(server_fd, name, send_byte);
}

int main()
{
    int status, login_status;
    struct sockaddr_in server_addr;
    //status: Biến để lưu trữ trạng thái của các hàm gọi.
    //login_status: Biến để lưu trữ trạng thái đăng nhập.
    //server_addr: Đối tượng kiểu struct sockaddr_in để lưu trữ địa chỉ server.

    //chương trình tạo socket server_fd và kết nối đến server sử dụng connect
    server_fd = socket(AF_INET, SOCK_STREAM, 0); // khoi tao ket noi
    /*
    Tạo một socket với domain là AF_INET, type là SOCK_STREAM và protocol là 0.
     Kết quả trả về là file descriptor server_fd của socket được tạo.
    */
    if (server_fd == -1)
    {
        fprintf(stderr, "create socket error\n");
        exit(0);
    }//Kiểm tra nếu server_fd bằng -1, tức là có lỗi trong quá trình tạo socket, in thông báo lỗi và thoát khỏi chương trình.

    memset(&server_addr, 0, sizeof(server_addr)); // đăt tất cả lại thành 0 để chuẩn bị lưu trữ địa chỉ server
    server_addr.sin_family = AF_INET;//Đặt domain của server_addr là AF_INET (IPv4).
    server_addr.sin_port = htons(PORT_NUM); //Đặt cổng của server_addr là giá trị PORT_NUM sau khi chuyển đổi từ kiểu dữ liệu short integer từ máy chủ thành network byte order bằng cách sử dụng hàm htons.
    if (inet_pton(AF_INET, SERVER_ADDR, &server_addr.sin_addr) == -1)
    {
        fprintf(stderr, "server_addr fail\n");
        exit(0);
    }//Chuyển đổi địa chỉ IP của server từ định dạng chuỗi thành dạng struct in_addr và lưu vào server_addr.sin_addr. Kiểm tra kết quả nếu bằng -1, tức là có lỗi trong quá trình chuyển đổi, in thông báo lỗi và thoát khỏi chương trình.

    status = connect(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)); //ket noi den server
    if (status == -1)
    {
        fprintf(stderr, "connect error\n");
        exit(0);
    }
    /*
    Kết nối tới server bằng cách sử dụng hàm connect với thông tin địa chỉ server và kích thước của server_addr. Kết quả trả về lưu vào status.
Kiểm tra nếu status bcằng -1, tức là có lỗi trong quá trình kết nối, in thông báo lỗi và thoát khỏi chương trình.
In thông báo "connect to server!" để xác nhận kết nối thành công.
    */

    printf("connect to server!\n");
    //Sau khi kết nối thành công, người dùng sẽ được yêu cầu nhập tên bằng hàm setname.
    setname(server_fd);

    /*
    hai luồng receive_thread và sent_thread được tạo để nhận và gửi tin nhắn.
     Vòng lặp vô hạn while (1) được sử dụng để tiếp tục chạy các luồng này.
    Hàm sleep(1) được sử dụng để ngăn chặn luồng chính kết thúc chương trình.
    */
    pthread_create(&receive_thread, NULL, receive_message, &server_fd); // nhan message
    //pthread_create(&receive_thread, NULL, receive_message, &server_fd): Tạo luồng receive_thread và gán nó cho hàm receive_message để nhận tin nhắn từ server.
    // Con trỏ &server_fd được truyền làm đối số cho hàm receive_message. Điều này cho phép luồng receive_thread truy cập và sử dụng biến server_fd trong hàm receive_message.
    pthread_create(&sent_thread, NULL, send_message, &server_fd); // gui message
    while (1)
        sleep(1);

    return 0;
}

/*
chương trình chat client trên cho phép người dùng kết nối và gửi/nhận tin nhắn với server thông qua socket. 
Các tin nhắn được mã hóa và giải mã bằng cách sử dụng module /dev/des_encrypt.
*/
