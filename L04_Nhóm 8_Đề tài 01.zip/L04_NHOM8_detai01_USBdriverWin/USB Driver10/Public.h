/*++

Module Name:

    public.h

Abstract:

    This module contains the common declarations shared by driver
    and user applications.

Environment:

    user and kernel

--*/

//
// Define an Interface Guid so that app can find the device and talk to it.
//

DEFINE_GUID (GUID_DEVINTERFACE_USBDriver10,
    0x2542d32d,0x4936,0x41ca,0x88,0xf7,0xf1,0x21,0x2a,0x15,0x5c,0xb2);
// {2542d32d-4936-41ca-88f7-f1212a155cb2}
