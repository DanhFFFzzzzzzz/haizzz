﻿#include <ntddk.h>

#define DEBUG_PRINT(format, ...) DbgPrint("[USB Driver] " format "\n", ##__VA_ARGS__)

// Hàm xử lý IRP_MJ_READ
NTSTATUS HandleReadIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // TODO: Xử lý đọc dữ liệu từ USB

    // Hiển thị thông báo trên Debug View
    DEBUG_PRINT("Copying data from USB");

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý IRP_MJ_WRITE
NTSTATUS HandleWriteIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // TODO: Xử lý ghi dữ liệu vào USB

    // Hiển thị thông báo trên Debug View
    DEBUG_PRINT("Copying data to USB");

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý các IRP khác
NTSTATUS HandleOtherIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    // TODO: Xử lý các loại IRP khác nếu cần thiết

    // Gọi hàm xử lý IRP mặc định
    IoSkipCurrentIrpStackLocation(Irp);
    return IoCallDriver(DeviceObject, Irp);
}

// Hàm xử lý IRP_MJ_CREATE và IRP_MJ_CLOSE
NTSTATUS HandleCreateCloseIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // Hiển thị thông báo trên Debug View
    DEBUG_PRINT("Create/Close IRP");

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý IRP
NTSTATUS DispatchIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    NTSTATUS status = STATUS_SUCCESS;
    PIO_STACK_LOCATION irpStack = IoGetCurrentIrpStackLocation(Irp);

    switch (irpStack->MajorFunction)
    {
    case IRP_MJ_READ:
        status = HandleReadIrp(DeviceObject, Irp);
        break;

    case IRP_MJ_WRITE:
        status = HandleWriteIrp(DeviceObject, Irp);
        break;

    case IRP_MJ_CREATE:
    case IRP_MJ_CLOSE:
        status = HandleCreateCloseIrp(DeviceObject, Irp);
        break;

    default:
        status = HandleOtherIrp(DeviceObject, Irp);
        break;
    }

    return status;
}

// Hàm xử lý các IRP tiếp theo
NTSTATUS DispatchNextIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    // Chuyển IRP cho lớp tiếp theo
    IoSkipCurrentIrpStackLocation(Irp);
    return IoCallDriver(DeviceObject, Irp);
}

// Hàm xử lý IRP tiếp theo
NTSTATUS DispatchDriver(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    // Xử lý IRP
    NTSTATUS status = DispatchIrp(DeviceObject, Irp);

    // Xử lý IRP tiếp theo nếu không thành công
    if (status != STATUS_SUCCESS)
    {
        status = DispatchNextIrp(DeviceObject, Irp);
    }

    return status;
}

// Hàm xử lý các yêu cầu IOCTL
NTSTATUS DispatchIoctl(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // TODO: Xử lý các yêu cầu IOCTL nếu cần thiết

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý các yêu cầu I/O
NTSTATUS DispatchRequest(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    NTSTATUS status = STATUS_SUCCESS;
    PIO_STACK_LOCATION irpStack = IoGetCurrentIrpStackLocation(Irp);

    switch (irpStack->MajorFunction)
    {
    case IRP_MJ_DEVICE_CONTROL:
        status = DispatchIoctl(DeviceObject, Irp);
        break;

    default:
        status = DispatchDriver(DeviceObject, Irp);
        break;
    }

    return status;
}

// Hàm xử lý IRP_MJ_POWER
NTSTATUS DispatchPower(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // TODO: Xử lý các yêu cầu Power nếu cần thiết

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    PoStartNextPowerIrp(Irp);
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý IRP_MJ_PNP
NTSTATUS DispatchPnp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // TODO: Xử lý các yêu cầu PnP nếu cần thiết

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý các IRP
NTSTATUS DriverDispatch(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    NTSTATUS status = STATUS_SUCCESS;
    UCHAR majorFunction = IoGetCurrentIrpStackLocation(Irp)->MajorFunction;

    switch (majorFunction)
    {
    case IRP_MJ_CREATE:
    case IRP_MJ_CLOSE:
    case IRP_MJ_READ:
    case IRP_MJ_WRITE:
        status = DispatchRequest(DeviceObject, Irp);
        break;

    case IRP_MJ_POWER:
        status = DispatchPower(DeviceObject, Irp);
        break;

    case IRP_MJ_PNP:
        status = DispatchPnp(DeviceObject, Irp);
        break;

    default:
        status = DispatchDriver(DeviceObject, Irp);
        break;
    }

    return status;
}

// Hàm xử lý IRP_MJ_CREATE
NTSTATUS HandleCreateIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // Hiển thị thông báo trên Debug View
    DEBUG_PRINT("Create IRP");

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý IRP_MJ_CLOSE
NTSTATUS HandleCloseIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // Hiển thị thông báo trên Debug View
    DEBUG_PRINT("Close IRP");

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

// Hàm xử lý IRP_MJ_DEVICE_CONTROL
NTSTATUS HandleDeviceControlIrp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    // TODO: Xử lý các yêu cầu IOCTL nếu cần thiết

    // Hoàn thành IRP
    Irp->IoStatus.Status = STATUS_SUCCESS;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
    UNREFERENCED_PARAMETER(RegistryPath);

    NTSTATUS status = STATUS_SUCCESS;

    // Đăng ký hàm xử lý IRP
    DriverObject->MajorFunction[IRP_MJ_CREATE] = HandleCreateIrp;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = HandleCloseIrp;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchRequest;
    DriverObject->MajorFunction[IRP_MJ_POWER] = DispatchPower;
    DriverObject->MajorFunction[IRP_MJ_PNP] = DispatchPnp;

    DriverObject->DriverUnload = NULL;

    // Hiển thị thông báo trên Debug View
    DEBUG_PRINT("USB Driver Loaded");

    return status;
}
